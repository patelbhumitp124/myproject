(function(){

    angular.module("register",[]);

    angular.module("register").config([function(){

        console.log("Config: register.js");
        
    }])
})();