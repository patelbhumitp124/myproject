(function(){

    angular.module("register").controller("registerCtrl", [registerCtrlFn]);

    function registerCtrlFn(){
        
    }
})();