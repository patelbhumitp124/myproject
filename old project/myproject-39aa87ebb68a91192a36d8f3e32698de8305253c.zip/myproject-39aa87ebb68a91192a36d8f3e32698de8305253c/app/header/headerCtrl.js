(function(){

    angular.module("header").controller("headerCtrl", [headerCtrlFn]);

    function headerCtrlFn(){
        
    }
})();