(function(){

    angular.module("header",[]);

    angular.module("header").config([function(){

        console.log("Config: header.js");
    }])
})();