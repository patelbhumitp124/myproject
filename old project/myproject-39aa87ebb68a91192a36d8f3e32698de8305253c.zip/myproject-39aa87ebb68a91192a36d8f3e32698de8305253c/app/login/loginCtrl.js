(function(){

    angular.module("login").controller("loginCtrl", [loginCtrlFn]);

    function loginCtrlFn(){
        
    }
})();