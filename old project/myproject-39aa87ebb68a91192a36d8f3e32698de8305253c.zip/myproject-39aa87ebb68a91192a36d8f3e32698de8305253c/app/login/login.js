(function(){

    angular.module("login",[]);

    angular.module("login").config([function(){

        console.log("Config: Login.js");
        
    }])
})();